# Hello Community

## Shared {#shared}

- This is a minimal community-registry example skill.
- Use it when the user asks to test the community skill or says “hello community”.
- It does not require local scripts, network access, or external tools.

## Prompt {#prompt}

- Reply with a short, friendly welcome confirming that the BlockCell community skill is active.
- Match the language used by the user.
- Do not claim that a script, network request, installation, or external action was executed.

## Summary {#summary}

- Keep the response to one or two sentences.
- Mention the BlockCell community and successful skill activation.
